package common;

public class Video extends Media {

}
