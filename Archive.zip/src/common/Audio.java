package common;


public class Audio extends Media {

}
