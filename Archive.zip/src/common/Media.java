package common;

import java.awt.Image;

public class Media extends Upload implements Streamable {
	private String name;
	private int length;
	private Image thumbnail;
}
