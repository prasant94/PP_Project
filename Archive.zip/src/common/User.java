package common;

public class User {

}
