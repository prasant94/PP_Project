package common;

public interface Streamable {

}
