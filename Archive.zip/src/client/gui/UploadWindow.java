package client.gui;


public class UploadWindow extends PopUpWindow {

}
