package client.gui;

import javax.swing.JPanel;

public class ItemPanel extends JPanel {

}
