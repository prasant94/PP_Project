package client.gui;

import javax.swing.JPanel;

public class SignInPanel extends JPanel {
	public SignInPanel() {
		// TODO
	}

	public	static boolean validateCredentials(String username, String password) {
		// TODO
		return false;
	}
}
