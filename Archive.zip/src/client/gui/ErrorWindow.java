package client.gui;

public class ErrorWindow extends PopUpWindow {
	/**
	 *
	 * @param err
	 */
	public ErrorWindow(String err) {
		
	}
}
