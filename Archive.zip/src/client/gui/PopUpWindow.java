package client.gui;

import javax.swing.JFrame;

public class PopUpWindow extends JFrame {
	/**
	 *
	 */
	public PopUpWindow() {
		// TODO
	}

	/**
	 *
	 */
	public void close() {
		// TODO
	}
}
