package client.gui;

import java.util.ArrayList;
import java.util.Comparator;

import javax.swing.JPanel;

public class ItemListPanel extends JPanel {
	private ArrayList<ItemPanel> items;

	/**
	 *
	 * @param comparator
	 */
	private void sortItems(Comparator comparator) {
		// TODO
	}
}
