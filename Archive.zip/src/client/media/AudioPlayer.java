package client.media;

public class AudioPlayer extends MediaPlayer {
	
	@Override
	public boolean play() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean pause() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean stop() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean close() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean Accept(MediaVisitor mediaVisitor) {
		// TODO Auto-generated method stub
		return false;
	}

}
