package client.media;

public class DownloadingVisitor extends MediaVisitor{

	@Override
	boolean visitAudioMedia(AudioPlayer audioPlayer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	boolean visitVideoMedia(VideoPlayer audioPlayer) {
		// TODO Auto-generated method stub
		return false;
	}


}
