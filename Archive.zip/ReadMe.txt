Open two terminals.
In one, compile the src/server/Server.java file and run it.
In the second, compile and run the src/client/gui/MainWindow.java file.
